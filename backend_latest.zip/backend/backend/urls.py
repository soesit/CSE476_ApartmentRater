from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include('api.urls')),
    path('api/auth/', include('rest_framework.urls')),  # optional browsable login
    path('api/token/', include('api.token_urls')),      # ✅ add this line
]
